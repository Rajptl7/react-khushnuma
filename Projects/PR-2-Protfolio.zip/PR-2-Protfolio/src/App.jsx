import React from 'react'
import Header from './components/Header';
import Slider from './components/Slider';
import Work from './components/Work';
import Contact from './components/Contact';
import Footer from './components/Footer';
import './App.css';

const App = () => {
  return (
    <>
      <header>
        <Header />
      </header>

      <main>
        <Slider />
        <Work />
        <Contact />
      </main>

      <footer>
        <Footer />
      </footer>

    </>
  )
}

export default App
