import React from 'react';

function Work() {
    return (
        <>
            <div className="py-5">

                <div className="container">
                    <h2 className="text-center mb-4">My Work</h2>
                    <div className="row g-4">
                        <div className="col-md-4">
                            <div className="card shadow">
                                <div className="card-body text-center">
                                    <h5 className="card-title">Project 1</h5>
                                    <p className="card-text">Website Development Project.</p>
                                    <button className="btn btn-primary">View Project</button>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-4">
                            <div className="card shadow">
                                <div className="card-body text-center">
                                    <h5 className="card-title">Project 2</h5>
                                    <p className="card-text">React JS Application.</p>
                                    <button className="btn btn-primary">View Project</button>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-4">
                            <div className="card shadow">
                                <div className="card-body text-center">
                                    <h5 className="card-title">Project 3</h5>
                                    <p className="card-text">Frontend Design Project.</p>
                                    <button className="btn btn-primary">View Project</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Work;