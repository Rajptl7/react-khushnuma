import React from 'react';

function Contact() {
    return (
        <>
            <div className="bg-light py-5">
                <div className="container">
                    <h2 className="text-center mb-4">Contact Me</h2>

                    <div className="row justify-content-center">
                        <div className="col-md-6">

                            <form>
                                <input type="text" className="form-control mb-3" placeholder="Enter Your Name" />

                                <input type="email" className="form-control mb-3" placeholder="Enter Your Email" />

                                <textarea className="form-control mb-3" rows="4" placeholder="Enter Your Message"></textarea>

                                <button className="btn btn-primary text-center w-100">Submit</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Contact;