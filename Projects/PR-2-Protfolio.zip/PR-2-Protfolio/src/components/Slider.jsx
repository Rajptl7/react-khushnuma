import React from 'react';

function Slider() {
    return (
        <>
            <div className="bg-primary  text-center py-5 text-white">
                <div className="container py-5">
                    <h1 className="display-4 fw-bold">
                        Welcome to My Portfolio
                    </h1>

                    <p>
                        I am a Web Developer passionate about creating websites.
                    </p>

                    <button className="btn btn-light ">
                        Explore More
                    </button>
                </div>
            </div>
        </>
    );
}

export default Slider;